import { CategoriesService } from './services/categories.service';
import { PostsService } from './services/posts.service';
import { AdminDashboardService } from './services/admin-dashboard.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';


import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HttpModule } from '@angular/http';
import { PostsComponent } from './posts/posts.component';
import { CategoriesComponent } from './categories/categories.component';
import { ContactMessagesComponent } from './contact-messages/contact-messages.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ContactMessagesService } from './services/contact-messages.service';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    DashboardComponent,
    PostsComponent,
    CategoriesComponent,
    ContactMessagesComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    RouterModule.forRoot([
      { 
        path: '', 
        component: DashboardComponent 
      },
      { 
        path: 'dashboard', 
        component: DashboardComponent 
      },
      { 
        path: 'posts', 
        component: PostsComponent 
      },
      { 
        path: 'categories', 
        component: CategoriesComponent 
      },
      { 
        path: 'contact-messages', 
        component: ContactMessagesComponent 
      },
      { 
        path: '**', 
        component: NotFoundComponent 
      }
    ])
  ],
  providers: [
    AdminDashboardService,
    PostsService,
    CategoriesService,
    ContactMessagesService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
