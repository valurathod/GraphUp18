import { CategoriesService } from './services/categories.service';
import { PostsService } from './services/posts.service';
import { AdminDashboardService } from './services/admin-dashboard.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HttpModule } from '@angular/http';
import { PostsComponent } from './posts/posts.component';
import { CategoriesComponent } from './categories/categories.component';
import { ContactMessagesComponent } from './contact-messages/contact-messages.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ContactMessagesService } from './services/contact-messages.service';
import { DomManipulationComponent } from './dom-manipulation/dom-manipulation.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { UserService } from './services/user.service';
import { AuthGuard } from './auth.guard';

const appRoute: Routes = [
  { 
    path: '', 
    component: LoginFormComponent 
  },
  { 
    path: 'dashboard', 
    canActivate: [AuthGuard],
    component: DashboardComponent 
  },
  { 
    path: 'posts', 
    canActivate: [AuthGuard],
    component: PostsComponent 
  },
  { 
    path: 'categories', 
    canActivate: [AuthGuard],
    component: CategoriesComponent 
  },
  { 
    path: 'contact-messages',
    canActivate: [AuthGuard], 
    component: ContactMessagesComponent 
  },
  { 
    path: 'dom', 
    component: DomManipulationComponent 
  },
  { 
    path: '**', 
    component: NotFoundComponent 
  }
];

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    DashboardComponent,
    PostsComponent,
    CategoriesComponent,
    ContactMessagesComponent,
    NotFoundComponent,
    DomManipulationComponent,
    LoginFormComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    RouterModule.forRoot(appRoute)
  ],
  providers: [
    AdminDashboardService,
    PostsService,
    CategoriesService,
    ContactMessagesService,
    UserService,
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
