import { AppErrorHandler } from './common/app-error-handler';
import { CategoriesService } from './services/categories.service';
import { PostsService } from './services/posts.service';
import { AdminDashboardService } from './services/admin-dashboard.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HttpModule } from '@angular/http';
import { PostsComponent } from './posts/posts.component';
import { CategoriesComponent } from './categories/categories.component';
import { ContactMessagesComponent } from './contact-messages/contact-messages.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ContactMessagesService } from './services/contact-messages.service';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    DashboardComponent,
    PostsComponent,
    CategoriesComponent,
    ContactMessagesComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { 
        path: '', 
        component: DashboardComponent 
      },
      { 
        path: 'dashboard', 
        component: DashboardComponent 
      },
      { 
        path: 'posts', 
        component: PostsComponent 
      },
      { 
        path: 'categories', 
        component: CategoriesComponent 
      },
      { 
        path: 'contact-messages', 
        component: ContactMessagesComponent 
      },
      { 
        path: '**', 
        component: NotFoundComponent 
      }
    ]),
    ModalModule.forRoot()
  ],
  providers: [
    AdminDashboardService,
    PostsService,
    CategoriesService,
    ContactMessagesService,
    { provide: ErrorHandler, useClass: AppErrorHandler } 
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
