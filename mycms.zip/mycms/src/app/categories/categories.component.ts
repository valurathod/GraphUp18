import { FormControl, Validators } from '@angular/forms';
import { BadInput } from './../common/bad-input';
import { InternalServerError } from './../common/internal-server-error';
import { NotFoundError } from './../common/not-found-error';
import { AppError } from './../common/app-error';
import { Component, OnInit } from '@angular/core';
import { CategoriesService } from '../services/categories.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {
  categories: any[] = [];
  control: FormControl;
  editedInput = false;
  constructor(private service: CategoriesService) {
    this.control = new FormControl('', [Validators.required]);
   }

  ngOnInit() {
    this.service.getAll('http://localhost/cms/public/api/categories').subscribe(categories => {
      this.categories = categories;
    });
  }
  addCategory(input: HTMLInputElement) {
    if(input.value === ''){
      alert('Category name is required');
      return false;
    }
    let categoryName = { name: input.value };
    input.value = '';
    this.categories.splice(0, 0, categoryName);
    this.service.create(categoryName, 'http://localhost/cms/public/api/add_categories').subscribe(newCat => {
      categoryName['id'] = newCat.id;
      //console.log(newCat);
    },
      (error: AppError) => {
        this.categories.splice(0, 1);
        if (error instanceof BadInput) {
          // this line directly shows errors on form page
          //this.form.setErrors(error.originalError);
          alert('Bad request: An unexpected error occurred.');
        }
        else throw error;
      });
    //console.log(categoryName);
  }

  deleteCategory(category) {
    let index = this.categories.indexOf(category);
    this.categories.splice(index, 1);
    this.service.delete('http://localhost/cms/public/api/delete_category', category.id).subscribe(null,
      (error: AppError) => {
        this.categories.splice(index, 0, category);
        if (error instanceof NotFoundError)
          alert("not found error...");
        if (error instanceof InternalServerError)
          alert("internal server error");
        else throw error;
      });
  }
    editCategory(category) {
      this.editedInput = true;
    }
}
