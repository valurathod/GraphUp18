import { Component, OnInit } from '@angular/core';
import { CategoriesService } from '../services/categories.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {
  categories: any[] = []; 
  constructor(private service: CategoriesService) { }

  ngOnInit() {
    this.service.getAll('http://localhost/api/categories').subscribe(categories => {
      this.categories = categories;
    });
  }
  addCategory(input: HTMLInputElement){
    let categoryName = { name: input.value };
    input.value = '';
    this.categories.splice(0, 0, categoryName);
    this.service.create(categoryName, 'http://localhost/api/add_categories').subscribe(newCat => {
      categoryName['id'] = newCat.id;
     //console.log(newCat);
    });
    //console.log(categoryName);
  }

  deleteCategory(category) {
    let index = this.categories.indexOf(category);
    this.service.delete('http://localhost/api/delete_category', category.id).subscribe(response => {
      this.categories.splice(index, 1);
      //console.log(response);
    });
  }
}
