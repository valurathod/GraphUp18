import { ErrorHandler } from '@angular/core';
export class AppErrorHandler implements ErrorHandler {
   handleError(error){
         //here will be toast message
        alert('An unexpected error occurred.');
        // here will be log error to db
        console.log(error); 
   }
}