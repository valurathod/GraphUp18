import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class DataService {

  constructor(private http: Http) { }
  getAll(url) {
    return this.http.get(url)
    .map(response => response.json());
  }

  create(resource, url) {
    //return Observable.throw(new AppError());
    let headers = new Headers({ 'Content-Type': 'application/json'});

  let options = new RequestOptions({ headers: headers });
    return this.http.post(url, JSON.stringify(resource), options)
        .map(response => response.json());
}

delete(url, id){
  return this.http.delete(url + '/' + id).map(response => response.json());
}
}
