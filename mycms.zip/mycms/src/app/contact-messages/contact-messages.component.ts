import { Component, OnInit } from '@angular/core';
import { ContactMessagesService } from '../services/contact-messages.service';

@Component({
  selector: 'app-contact-messages',
  templateUrl: './contact-messages.component.html',
  styleUrls: ['./contact-messages.component.css']
})
export class ContactMessagesComponent implements OnInit {
  contactMessages: any[] = [];
  constructor(private service: ContactMessagesService) { }

  ngOnInit() {
    this.service.getAll('http://localhost/api/contact-messages').subscribe(contactMessages => {
      this.contactMessages = contactMessages;
    });
  }
  
  deleteContactMessage(contactMessage){
   let index = this.contactMessages.indexOf(contactMessage);
   this.service.delete('http://localhost/api/deleteMessage', contactMessage.id).subscribe(
     response => {
       this.contactMessages.splice(index, 1);
      // console.log(response);
     });
  }
}
