import { InternalServerError } from './../common/internal-server-error';
import { NotFoundError } from './../common/not-found-error';
import { AppError } from './../common/app-error';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { ContactMessagesService } from '../services/contact-messages.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-contact-messages',
  templateUrl: './contact-messages.component.html',
  styleUrls: ['./contact-messages.component.css']
})
export class ContactMessagesComponent implements OnInit {
  contactMessages: any[] = [];
  public modalRef: BsModalRef;
  contactMessage : any;//used to pass data to modal
  constructor(private service: ContactMessagesService, private modalService: BsModalService) { }

  ngOnInit() {
    this.service.getAll('http://localhost/cms/public/api/contact-messages').subscribe(contactMessages => {
      this.contactMessages = contactMessages;
    });
  }

  deleteContactMessage(contactMessage) {
    let index = this.contactMessages.indexOf(contactMessage);
    this.contactMessages.splice(index, 1);
    this.service.delete('http://localhost/cms/public/api/deleteMessage', contactMessage.id)
      .subscribe(
      null,
      (error: AppError) => {
        this.contactMessages.splice(index, 0, contactMessage);
        if (error instanceof NotFoundError)
          alert("not found error...");
        if (error instanceof InternalServerError)
          alert("internal server error");
        else throw error;
      });
  }
  openModal(template: TemplateRef<any>, contactMessage: any) {
    this.contactMessage = contactMessage;
    this.modalRef = this.modalService.show(template); 
  }
}
