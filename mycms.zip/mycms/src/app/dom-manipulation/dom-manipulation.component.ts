import { Component, OnInit, AfterViewInit, ViewChild, ElementRef, ViewContainerRef, TemplateRef } from '@angular/core';


@Component({
  selector: 'app-dom-manipulation',
  templateUrl: './dom-manipulation.component.html',
  styleUrls: ['./dom-manipulation.component.css']
})
export class DomManipulationComponent implements AfterViewInit {
  @ViewChild("tpl") tpl: TemplateRef<any>;

    ngAfterViewInit() {
        let elementRef = this.tpl.elementRef;
        // outputs `template bindings={}`
        console.log(elementRef.nativeElement.textContent);
    }
}
