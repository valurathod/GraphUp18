import { Observable } from 'rxjs/Observable';
import { AdminDashboardService } from './../services/admin-dashboard.service';
import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  dashboardData: any[];
  posts: any[];
  contactMessages: any[];
  constructor(private service: AdminDashboardService) { }

  ngOnInit() {
    this.service.getAll('http://localhost/api/dashboard').subscribe(dashboardData => {
      this.dashboardData = dashboardData;
      this.posts = this.dashboardData['posts'];
      this.contactMessages = this.dashboardData['contact_messages'];
     // console.log(this.posts);
    });

  }

}
