function hi()
{
console.log("Into function..");
alert("HI!!!!");
}

 /* function table()
{
for(i=1;i<=10;i++)
document.writeln("\n"+44+" * "+i+" = "+i*44 );
} */
