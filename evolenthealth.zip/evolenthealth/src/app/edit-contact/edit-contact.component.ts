import { Component, OnInit } from '@angular/core';
import { ContactModel } from '../contact-model';

@Component({
  selector: 'app-edit-contact',
  templateUrl: './edit-contact.component.html',
  styleUrls: ['./edit-contact.component.css']
})
export class EditContactComponent implements OnInit {

  private contact : ContactModel;
  constructor(){
    this.contact = new ContactModel({
      firstname: 'valu',
      lastname: 'rathod',
      emailaddress: 'valu@gmail.com',
      phonenumber: 9021134459,
      status: 'inactive'
      });
  }
  ngOnInit() {
  }
  onFormSubmit({ value, valid}: { value: ContactModel, valid: boolean }) {
    this.contact = value;
    console.log( this.contact);
    console.log('valid: ' + valid);
}
}
