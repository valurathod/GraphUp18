var mysql = require('mysql')

var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'test'
})

connection.connect(function(err) {
  if (err) throw err
  console.log('You are now connected...')
  connection.query('CREATE TABLE people5(id int primary key, name varchar(255), age int, address text)', function(err, result) {
    if (err) throw err
	console.log('table created')
	connection.query('INSERT INTO people5 (id,name, age, address) VALUES (?, ?, ?,?)', ['1', 'Adam','22','USA'], function(err, result) {
      if (err) throw err
      connection.query('SELECT * FROM people5', function(err, results) {
        if (err) throw err
        console.log(results[0].id)
        console.log(results[0].name)
        console.log(results[0].age)
        console.log(results[0].address)
      })
    })
  }) 
})
//steps for database connectivity

//npm install express-if not uninstalled then
//npm install mysql
//node database_connect.js
//output--display the records on cmd
 //one example for sequelize