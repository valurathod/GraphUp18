"use strict";

console.log('Before file read');

const fs = require('fs');
const fileName = 'mynewfile1.txt';

fs.readFile(fileName, function foo(err, data) {
    if (err) {
        throw err;
    }

    var text = data.toString();
    console.log('--------------\n' + text + '\n---------------------');
});

console.log('After file read');

//----------------------------------------------------------------------------------------
/*
console.log('Before file read');

const fs = require('fs');
const fileName = 'mynewfile1.txt';

var data = fs.readFileSync(fileName);
var text = data.toString();
console.log('--------------\n' + text + '\n---------------------');

console.log('After file read');
*/