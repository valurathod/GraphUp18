var os = require('os');
var d=require('util');

var toMb = function(f) {
    return(Math.round((f/1024/1024)*100)/100);
}
console.log(new Date().getYear());
console.log('Host: ' + os.hostname());
console.log('15 min. load average: ' + os.loadavg()[2]);
console.log(toMb(os.freemem()) + ' of ' + toMb(os.totalmem()) + ' Mb free');

   /*'assert',
  'buffer',
  'child_process',
  'cluster',
  'crypto',
  'dgram',  vibha vishwanath shilpa J
  'dns',
  'domain',
  'events',
  'fs',
  'http',
  'https',
  'net',
  'os',
  'path',
  'punycode',
  'querystring',
  'readline',
  'stream',
  'string_decoder',
  'tls',
  'tty',
  'url',
  'util',
  'v8',
  'vm',
  'zlib' ]*/
