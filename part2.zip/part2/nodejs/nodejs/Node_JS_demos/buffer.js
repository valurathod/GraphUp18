var b = new Buffer(10000);
var str = "                         ";
b.write(str); // default is utf8, which is what we want
console.log( b.length ); // will print 10000 still!
console.log(str);


// a string 
var str = "Hello World in Node jS"; 

// From string to buffer 
var buffer = new Buffer(str, 'utf-8'); 
console.log(buffer);

// From buffer to string 
var roundTrip = buffer.toString('utf-8'); 
console.log(roundTrip); // Hello 


/*
In Node.js we can manipulate Binary Data with Buffers.

When working with streams and files, we work mostly with the Buffer class.

Buffer hold binary data that can be converted into other formats, used in operations to file writes, or broken apart and reassembled.

Buffer's length property does not return the size of the content, but that of the buffer itself!*/