var buffer1 = new Buffer(10);
var buffer2 = new Buffer([10, 20, 30, 40]);
var buffer3 = new Buffer('Some string here', 'utf-8');

var len = buffer1.write('something here');

console.log(len + ' characters written');

console.log(buffer1.toString());

var buffer = new Buffer(26);

for (var i = 0; i < 26; i++) {
    buffer[i] = 97 + i;
}

console.log(buffer.toString('ascii'));
console.log(buffer.toString('ascii', 0, 5));
console.log(buffer.toString('utf-8', 0, 5));
console.log(buffer.toString(undefined, 0, 5));      // Default encoding is utf-8
console.log(buffer.toJSON());