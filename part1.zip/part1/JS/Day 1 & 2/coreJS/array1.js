//Create an Array

var fruits = ["Apple", "Banana"];

console.log(fruits); // 2
//Access (index into) an Array item

var first = fruits[0]; // Apple

var last = fruits[fruits.length - 1];// Banana
//Loop over an Array

fruits.forEach(function (item, index, array) {
  console.log(item, index);
});// Apple 0	
// Banana 1
//Add to the end of an Array

var newLength = fruits.push("Orange");
// ["Apple", "Banana", "Orange"]
//Remove from the end of an Array
console.log(fruits);



var last = fruits.pop(); // remove Orange (from the end)
// ["Apple", "Banana"]; 
console.log(fruits);
//Remove from the front of an Array

var first = fruits.shift(); // remove Apple from the front
// ["Banana"];
//Add to the front of an Array
console.log(fruits);

var newLength = fruits.unshift("Strawberry") // add to the front
// ["Strawberry", "Banana"];
//Find the index of an item in the Array
console.log(fruits);
fruits.push("Mango");
// ["Strawberry", "Banana", "Mango"]
console.log(fruits);
var pos = fruits.indexOf("Banana");
// 1
//Remove an item by Index Position
console.log(pos);
var removedItem = fruits.splice(pos, 1); // this is how to remove an item
// ["Strawberry", "Mango"]
//Copy an Array
console.log(fruits);

var shallowCopy = fruits.slice(); // this is how to make a copy
// ["Strawberry", "Mango"]
console.log(fruits);