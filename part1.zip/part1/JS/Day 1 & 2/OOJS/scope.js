var x = 10;
var y = 10;
{
    var x = 5;
    var y = 5;
	function fun()
    {
        var x = 2;
        var y = 2;
        document.write("x: " + x + "<br/>");
        document.write("y: " + y + "<br/>");
       
    }
	fun();
    document.write("x: " + x + "<br/>");
    document.write("y: " + y + "<br/>");
    }
document.write("x: " + x + "<br/>");
document.write("y: " + y + "<br/>");

//***Example1***********//
<html>
<body>
<p>
If you assign a value to a variable that has not been declared,
it will automatically become a GLOBAL variable:
</p>

<p id="demo"></p>

<script>
myFunction();


document.getElementById("demo").innerHTML = "I can display " + carName;

function myFunction() {
    carName = "Volvo";
}
</script>

</body>
</html>



//********Example2***********//
/* A local variable can have the same name as a global variable, but it is entirely separate; changing the value of one variable has no effect on the other. Only the local version has meaning inside the function in which it is declared. */
// Global definition of aCentaur.
var aCentaur = "a horse with rider,";

// A local aCentaur variable is declared in this function.
function antiquities(){

   var aCentaur = "A centaur is probably a mounted Scythian warrior";
}

antiquities();
aCentaur += " as seen from a distance by a naive innocent.";

document.write(aCentaur);



//******Example3***********//
var aNumber = 100;
tweak();

function tweak(){

   
    document.write(aNumber);

    if (false)
    {
        var aNumber = 123;  
    }
}

//********Example4***********//
function send(name) {
    // Local variable 'name' is stored in the closure
    // for the inner function.
    return function () {
        sendHi(name);
    }
}

function sendHi(msg) {
    console.log('Hello ' + msg);
}

var func = send('Bill');
func();
/
sendHi('Pete');
/
func();
// 
