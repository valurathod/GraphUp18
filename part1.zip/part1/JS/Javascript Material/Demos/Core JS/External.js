function Test() {
    alert("This function is written in external JavaScript file");
}