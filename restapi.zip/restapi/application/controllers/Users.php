<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
       
    }

	public function index()
	{
				$response = array('status' => 200,'message' => 'Authorized.');
		        	$resp = $this->MyModel->get_users_data();
	    			json_output($response['status'],$resp);
	}
	
	public function get_users()
	{
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'GET'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
				$response = array('status' => 200,'message' => 'Authorized.');
		        	$resp = $this->MyModel->get_users_data();
	    			json_output($response['status'],$resp);
		}			
	}

	public function get_user($id)
	{
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'GET' || $this->uri->segment(3) == '' || is_numeric($this->uri->segment(3)) == FALSE){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			 $response = array('status' => 200,'message' => 'Authorized.');
		        if($response['status'] == 200){
		        	$resp = $this->MyModel->user_detail_data($id);
					json_output($response['status'],$resp);
		        }
			}
	}

	public function add_user()
	{
		 $method = $_SERVER['REQUEST_METHOD'];
		if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
		        $response = array('status' => 200,'message' => 'Authorized.');
		        $respStatus = $response['status'];
		        if($response['status'] == 200){
					if ($_REQUEST['first_name'] == "" || $_REQUEST['last_name'] == "" || $_REQUEST['username'] == "" || $_REQUEST['email'] == "") {
						$respStatus = 400;
						$resp = array('status' => 400,'message' =>  'Details can\'t empty');
					} else {
						$params['first_name'] = $_REQUEST['first_name'];
						$params['last_name'] = $_REQUEST['last_name'];
						$params['username'] = $_REQUEST['username'];
						$params['email'] = $_REQUEST['email'];
		        		$resp = $this->MyModel->add_user_data($params);
					}
					json_output($respStatus,$resp);
		        }
		}		
	}

	public function update_user($id)
	{
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'PUT' || $this->uri->segment(3) == '' || is_numeric($this->uri->segment(3)) == FALSE){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			$response = array('status' => 200,'message' => 'Authorized.');
		        $respStatus = $response['status'];
		        if($response['status'] == 200){
					if ($_REQUEST['first_name'] == "" || $_REQUEST['last_name'] == "" || $_REQUEST['username'] == "" || $_REQUEST['email'] == "") {
						$respStatus = 400;
						$resp = array('status' => 400,'message' =>  'Details can\'t empty');
					} else {
						$params['first_name'] = $_REQUEST['first_name'];
						$params['last_name'] = $_REQUEST['last_name'];
						$params['username'] = $_REQUEST['username'];
						$params['email'] = $_REQUEST['email'];
						$params['updated_at'] = date('Y-m-d H:i:s');
		        		$resp = $this->MyModel->user_update_data($id,$params);
					}
					json_output($respStatus,$resp);
		        }
			}
	}

	public function delete_user($id)
	{
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'DELETE' || $this->uri->segment(3) == '' || is_numeric($this->uri->segment(3)) == FALSE){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			       $response = array('status' => 200,'message' => 'Authorized.');
			        if($response['status'] == 200){
		        	$resp = $this->MyModel->user_delete_data($id);
					json_output($response['status'],$resp);
		        }
			}
	}

}
