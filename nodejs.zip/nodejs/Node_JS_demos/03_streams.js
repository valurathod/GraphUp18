const fs = require('fs');
var data = '';

// Create a readable stream
var readerStream = fs.createReadStream('mynewfile3.txt');

readerStream.setEncoding('utf8');

readerStream.on('data1', function readData(chunk) {
    data1 += chunk;
});

readerStream.on('end', function handleEnd() {
    console.log('Read completed');
    console.log(data);
});

readerStream.on('error', function handleError(err) {
    console.log(err);
});

console.log('Reader demo ended');

/*
//----------------------------------------------------------------------------------------
// Create a writable stream
var writerStream = fs.createWriteStream('output.txt');
data = 'some text';

writerStream.on('finish', function handleFinish() {
    console.log('Write completed');
});

writerStream.on('error', function handleFinish(err) {
    console.log(err);
});

writerStream.write(data, 'utf8');

writerStream.end();

console.log('Writer demo ended');
*/
/*
//----------------------------------------------------------------------------------------
// Piping the streams
var readerStream = fs.createReadStream('data.csv');
var writerStream = fs.createWriteStream('output.txt');

readerStream.pipe(writerStream);
*/
/*
//----------------------------------------------------------------------------------------
// Chaining the streams
var zlib = require('zlib');
fs.createReadStream('data.csv')
    .pipe(zlib.createGzip())
    .pipe(fs.createWriteStream('data.csv.gz'));

console.log('File compressed');

/*
fs.createReadStream('data.csv.gz')
    .pipe(zlib.createGunzip())
    .pipe(fs.createWriteStream('data.csv.gz.u'));

console.log('File decompressed');

*/
//----------------------------------------------------------------------------------------
/* dont need below 
const http = require('http');

const server = http.createServer( function handleServer(req, res) {
    // req is http.IncomingMessage, which is a readable stream
    // res is http.ServerResponse, which is a writable stream

    let body = '';

    req.setEncoding('utf8');

    req.on('data', function readData(chunk) {
        body += chunk;
    });

    req.on('end', function dataReceived() {
        try {
                const data = JSON.parse(body);
                res.write(typeof data);
                res.end();
        } catch (e) {
            res.statusCode = 400;
            return res.end(`error: ${e.message}`);
        }
    });
});

server.listen(3000);
*/