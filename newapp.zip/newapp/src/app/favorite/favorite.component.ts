import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'favorite',
  templateUrl: './favorite.component.html',
  styleUrls: ['./favorite.component.css'],
  styles : [
    `
    .glyphicon {
    color: green;
}
    `
  ]
})
export class FavoriteComponent implements OnInit {
  @Input('is-favorite') isSelected: boolean;
  @Output('change') click = new EventEmitter();
  
  constructor() { console.log(this.isSelected); }

  ngOnInit() {
  }
  onclick() {
    this.isSelected = !this.isSelected;
    this.click.emit({ newValue : this.isSelected });
  }
}

export interface FavoriteChangedEventArgs {
  newValue : boolean
}