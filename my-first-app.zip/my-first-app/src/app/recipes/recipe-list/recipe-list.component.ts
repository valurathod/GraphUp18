import { Recipe } from './../recipe.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  recipes: Recipe[] = [
    new Recipe('A test recipe', 'This is simply a test', 'http://www.kraftrecipes.com/-/media/assets/recipe_images/pollo-con-queso-y-salsa-111147-600x250.jpg?h=250&w=600&la=en&hash=59A017384020E7E136E1A5EB808962A19C47191A'),
    new Recipe('A test recipe', 'This is simply a test', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYLqLU7-8k5EmXG13T9lTBhVNmAC-IDQdKZVQYthQhcNlFjq8hlA')
  ];
  constructor() { }

  ngOnInit() {
  }

}
