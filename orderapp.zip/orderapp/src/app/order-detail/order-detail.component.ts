import { DataService } from './../services/data.service';
import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'order-detail',
  templateUrl: './order-detail.component.html',
  styleUrls: ['./order-detail.component.css']
})
export class OrderDetailComponent implements OnInit {
  // @Input() orderId: string;
  orders: any[] = [];
  selectedOrder: boolean = false;
  constructor(private dataservice: DataService) { }

  ngOnInit() {
    
  }
  orderDetail(orderId) {
    this.orders = [];
    this.dataservice.getAll('./assets/data/api/order.json')
    .subscribe(res => {
      res.forEach(element => {
         if(orderId == element.orderId)
          this.orders.splice(0, 0, element);
      });
      this.selectedOrder = true;
    }, error => {
      console.log('Error : ' + error);
    });
  }

  closeChild(){
    this.selectedOrder = false;
  }
}
