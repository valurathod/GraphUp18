import { OrderDetailComponent } from './../order-detail/order-detail.component';
import { DataService } from './../services/data.service';
import { UserService } from './../services/user.service';
import { NavbarService } from './../services/navbar.service';
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit, AfterViewInit {

  @ViewChild(OrderDetailComponent) child: OrderDetailComponent;
  username: string;
  orders: any[] = [];
  orderDetails: any[] = [];
  orderData: any[] = [];
  customerId: string;
  selectedRow: number;
  selectedOrder: boolean = false;
  dataArray: any[] = [];
  constructor(
    private navBarService: NavbarService,
    private user: UserService,
    private dataservice: DataService
  ) { }
  ngAfterViewInit() {

  }
  ngOnInit() {
    this.navBarService.setNavBarState(this.user.getUserLoggedIn());
    this.username = this.user.getName();
    this.customerId = this.user.getUsername();
    this.dataservice.currentOrderData.subscribe(orderData => this.orderData = orderData);
    //console.log(Math.floor(Math.random() * 999) + 100 );
    this.dataservice.getAll('./assets/data/api/order.json')
      .subscribe(res => {
        res.forEach(element => {
          if (this.customerId == element.customerId)
            this.orders.splice(0, 0, element);
        });
        if (this.orderData['product']) {
          let newOrder = {
            "orderId": Math.floor(Math.random() * 999) + 100,
            "customerId": this.customerId,
            "product": this.orderData['product'],
            "quantity": this.orderData['quantity']
          };
          this.orderData['orderId'] = Math.floor(Math.random() * 999) + 100;
          this.orderData['customerId'] = this.customerId;
          console.log(newOrder);
          this.orders.splice(0, 0, newOrder);
        }
        console.log(this.orders);
      }, error => {
        console.log('Error : ' + error);
      });
  }

  getOrderDetail(order, rowid) {

    //this.child.orderDetail(order.orderId);
    this.selectedRow = rowid;
    this.orderDetails = [];
    this.orders.forEach(element => {
      if (order.orderId == element.orderId)
        this.orderDetails.splice(0, 0, element);
    });
    this.selectedOrder = true;
  }
  closeDetailBox() {
    this.selectedOrder = false;
  }
}
