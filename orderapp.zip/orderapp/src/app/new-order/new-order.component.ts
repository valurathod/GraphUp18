import { Router } from '@angular/router';
import { DataService } from './../services/data.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-new-order',
  templateUrl: './new-order.component.html',
  styleUrls: ['./new-order.component.css']
})
export class NewOrderComponent implements OnInit {
  private products: any[] = [];
  product: string = '';
  quantity: number = 0;
  orderData: any[] = [];

  constructor(private dataservice: DataService, private router: Router) { }

  ngOnInit() {
    this.dataservice.currentOrderData.subscribe(orderData => this.orderData = orderData);
    this.dataservice.getAll('./assets/data/api/product.json')
    .subscribe(res => {
      this.products = res;
    }, error => {
      console.log('Error : ' + error);
    });
  }
  
  onSubmit(input: NgForm) {
    this.dataservice.changeOrderData(input.value);
    //console.log(input.value);
    this.product = input.value.product;
    this.quantity = input.value.quantity;
    this.router.navigate(['/user-dashboard']);
    //console.log(this.product);
  }
}
