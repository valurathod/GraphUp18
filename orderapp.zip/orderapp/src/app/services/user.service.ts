import { CookieService } from 'ngx-cookie-service';
import { DataService } from './data.service';
import { Injectable } from '@angular/core';

@Injectable()
export class UserService {
  private isUserLoggedIn;
  private username;
  private name;
  customers: any[] = [];
  constructor(private service: DataService, private cookie: CookieService) {
    this.isUserLoggedIn = false;
  }
  setUserLoggedIn() {
    this.isUserLoggedIn = true;
  }
  getUserLoggedIn() {
    if (this.cookie.get('isUserLoggedIn') == 'true')
      return true;
    else
      return false;
  }
  setUserLoggedOut() {
    this.isUserLoggedIn = false;
    this.cookie.deleteAll();
  }
  loginCheck(username, password) {
    return this.service.getAll('./assets/data/api/user.json')
      .map(res => {
        if (res['customers'].length > 0) {
          res['customers'].forEach(element => {

            if (username == element.customerId && password == element.password) {
              this.cookie.set('isUserLoggedIn', 'true');
              this.isUserLoggedIn = true;
              this.cookie.set('username', username);
              //this.username = username;
              this.cookie.set('name', element.name);
              //this.name = element.name;
            }
          });
        }
        return this.isUserLoggedIn;
      }, (error: any) => {
        console.log('Error : ' + error);
      });

  }

  getName() {
    if (this.cookie.check('name'))
      return this.cookie.get('name');
    else
      return null;
  }

  getUsername() {
    if (this.cookie.check('username'))
      return this.cookie.get('username');
    else
      return null;
  }
}

