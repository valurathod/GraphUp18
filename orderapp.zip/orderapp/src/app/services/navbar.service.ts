import { Injectable } from '@angular/core';
import { Subject } from 'RxJs';

@Injectable()
export class NavbarService {
  private navStateSource = new Subject<boolean>();
  navState$ = this.navStateSource.asObservable();
  constructor() { }
  setNavBarState(state: boolean) {
    this.navStateSource.next(state);
  }
}
