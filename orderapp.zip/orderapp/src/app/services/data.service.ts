import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class DataService {
   private orderData = new BehaviorSubject<any>([]);
  currentOrderData = this.orderData.asObservable();

  constructor(private http: Http) { }
  getAll(url) {
    return this.http.get(url).map(response => response.json());
  }

  changeOrderData(orderData: any) {
    this.orderData.next(orderData)
  }
}
