import { Http } from '@angular/http';
import { DataService } from './../services/data.service';
import { Component, OnInit } from '@angular/core';
import { forkJoin } from "rxjs/observable/forkJoin";
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-view-orders',
  templateUrl: './view-orders.component.html',
  styleUrls: ['./view-orders.component.css']
})
export class ViewOrdersComponent implements OnInit {
  orders: any[] = [];
  
  loadedCharacter: {};

  constructor(private dataservice: DataService, private http: Http) { }

  ngOnInit() {
    this.combineRequest();
  }
  
  combineRequest() {
    let order = this.http.get('./assets/data/api/order.json').map(res => res.json());
    let product = this.http.get('./assets/data/api/product.json').map(res => res.json());

    forkJoin([order, product]).subscribe(results => {
      //results[0] is order array
      //results[1] is product array
      results[0].forEach(element => {
        let product = element.product;
        let name = '';
        results[1].forEach(element1 => {
          if (product == element1.productId) {
            name = element1.name;
          }
        });
        element['name'] = name;
        this.orders.splice(0, 0, element);
      });
    });
  }
}
