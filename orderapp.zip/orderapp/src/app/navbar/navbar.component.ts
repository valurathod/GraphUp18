import { NavbarService } from './../services/navbar.service';
import { Router } from '@angular/router';
import { UserService } from './../services/user.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  isUserLoggedIn: boolean = false;
  constructor(private user: UserService, private router: Router, private navBarService: NavbarService) { 
    this.navBarService.navState$.subscribe( (state)=> this.isUserLoggedIn = state );
  }
 
  ngOnInit() {
    this.isUserLoggedIn = this.user.getUserLoggedIn();
    console.log(this.isUserLoggedIn);
  }

  logout() {
    this.user.setUserLoggedOut();
    this.navBarService.setNavBarState(this.user.getUserLoggedIn());
    this.router.navigate(['/']);
  }
}
