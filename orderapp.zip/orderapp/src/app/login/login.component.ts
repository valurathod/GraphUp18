import { NavbarService } from './../services/navbar.service';
import { UserService } from './../services/user.service';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  title = 'Welcome to Order App!';
  isValid: boolean = true;
  constructor(private user: UserService, private router: Router, private navBarService: NavbarService) { }

  ngOnInit() {
    this.user.setUserLoggedOut();
  }
  loginUser(event) {
    event.preventDefault();
    let username = event.target.elements[0].value;
    let password = event.target.elements[1].value;
    if(username == '' || password == '')
      return;
   this.user.loginCheck(username, password).subscribe(res => {
    if(res && username == 'admin') {
      this.navBarService.setNavBarState(this.user.getUserLoggedIn());
      console.log('in if');
      //console.log(username);
      //this.user.setUserLoggedIn();
      this.router.navigate(['/admin-dashboard']);
    }else if(res && username != 'admin') {
      console.log('in second if');
      this.router.navigate(['/user-dashboard']);
    }else{
      console.log('in else');
      this.isValid = false;
    }
    });
    
    
    
    
  }
}
