import { UserService } from './../services/user.service';
import { NavbarService } from './../services/navbar.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  username: string; 
  constructor(
    private navBarService: NavbarService, 
    private user: UserService,
  ) { }

  ngOnInit() {
    this.navBarService.setNavBarState(this.user.getUserLoggedIn());
    this.username = this.user.getName();
  }

}
