import { element } from 'protractor';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { Http } from '@angular/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-customer-order-list',
  templateUrl: './customer-order-list.component.html',
  styleUrls: ['./customer-order-list.component.css']
})
export class CustomerOrderListComponent implements OnInit {
  customerId: string;
  orderList: any[] = [];
  constructor(
    private activatedRoute: ActivatedRoute, 
    private http: Http,
    private router: Router
  ) { }

  ngOnInit() {
    this.customerId = this.activatedRoute.snapshot.params['id'];
    this.combineRequest();
  }
  
  combineRequest() {
    let order = this.http.get('./assets/data/api/order.json').map(res => res.json());
    let product = this.http.get('./assets/data/api/product.json').map(res => res.json());

    forkJoin([order, product]).subscribe(results => {
      //results[0] is order array
      //results[1] is product array
      //console.log(results);
      results[0].forEach(element => {
        let customerId = element.customerId;
        if(this.customerId == element.customerId){
          let product = element.product;
          let name = '';
        results[1].forEach(element1 => {
          if (product == element1.productId) {
            name = element1.name;
          }
        });
        element['name'] = name;
        this.orderList.splice(0, 0, element);
        }
      });
    });
  }
  
  goBack(){
   this.router.navigate(['/view-customers']); 
  }
}
