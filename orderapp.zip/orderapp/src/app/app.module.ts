import { AuthGuard } from './auth.guard';
import { NavbarService } from './services/navbar.service';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { UserService } from './services/user.service';
import { DataService } from './services/data.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { CookieService } from 'ngx-cookie-service';
import { FormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { NavbarComponent } from './navbar/navbar.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { OrderDetailComponent } from './order-detail/order-detail.component';
import { NewOrderComponent } from './new-order/new-order.component';
import { ViewOrdersComponent } from './view-orders/view-orders.component';
import { ViewCustomersComponent } from './view-customers/view-customers.component';
import { CustomerOrderListComponent } from './customer-order-list/customer-order-list.component';


const appRoutes: Routes = [
{
  path: '', 
  component: LoginComponent 
},
{
  path: 'admin-dashboard',
  canActivate: [AuthGuard],
  component: AdminDashboardComponent
},
{
  path: 'user-dashboard',
  canActivate: [AuthGuard],
  component: UserDashboardComponent
},
{
  path: 'new-order',
  canActivate: [AuthGuard],
  component: NewOrderComponent
},
{
  path: 'view-orders',
  canActivate: [AuthGuard],
  component: ViewOrdersComponent
},
{
  path: 'view-customers',
  canActivate: [AuthGuard],
  component: ViewCustomersComponent
},
{
  path: 'order-list/:id',
  canActivate: [AuthGuard],
  component: CustomerOrderListComponent
}
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NavbarComponent,
    AdminDashboardComponent,
    UserDashboardComponent,
    OrderDetailComponent,
    NewOrderComponent,
    ViewOrdersComponent,
    ViewCustomersComponent,
    CustomerOrderListComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [
    DataService,
    UserService,
    NavbarService,
    CookieService,
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
