import { forkJoin } from 'rxjs/observable/forkJoin';
import { Http } from '@angular/http';
import { Component, OnInit } from '@angular/core';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-view-customers',
  templateUrl: './view-customers.component.html',
  styleUrls: ['./view-customers.component.css']
})
export class ViewCustomersComponent implements OnInit {
  customers: any[] = [];
  constructor(private http: Http) { }

  ngOnInit() {
    this.combineRequest();
  }
  
  combineRequest() {
    let order = this.http.get('./assets/data/api/order.json').map(res => res.json());
    let user = this.http.get('./assets/data/api/user.json').map(res => res.json());

    forkJoin([order, user]).subscribe(results => {
      //results[0] is order array
      //results[1] is customers array
      results[1]['customers'].forEach(element => {
        let customerId = element.customerId;
        let orderPlaced = 0;
        results[0].forEach(element1 => {
          if (customerId == element1.customerId) {
            orderPlaced++;
          }
        });
        let index = this.customers.length;
        //console.log(arrLength);
        element['orderPlaced'] = orderPlaced;
        this.customers.splice(index, 0, element);
      });
    });
  }

}
