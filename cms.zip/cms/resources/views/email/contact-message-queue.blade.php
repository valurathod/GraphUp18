<h1>A new contact message was sent!</h1>
<h3>Information about your message</h3>