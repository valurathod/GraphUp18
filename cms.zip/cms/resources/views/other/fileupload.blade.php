@extends('layouts.master')

@section('title')
  Contact
@endsection

@section('styles')
  <link rel="stylesheet" href="{{ URL::to('css/form.css') }}">
@endsection
@section('content')
 @include('includes.info-box')
 @if ($message = Session::get('success'))
 <!--<img src="images/{{ Session::get('fileupload') }}" height="200" width="300">-->
 <a href="images/{{ Session::get('fileupload') }}" target="_blank">{{ Session::get('fileupload') }}</a>
 @endif
 {!! Form::open(array('route' => 'upload.post','files'=>true, 'id' => 'contact-form')) !!}
    <div class="input-group">
     {!! Form::file('fileupload', array('id' => 'fileupload')) !!}
   </div>
   {!! Form::submit('Submit message', ['class' => 'btn']) !!}

 {!! Form::close() !!}
@endsection 