@extends('layouts.master')

@section('title')
  Contact
@endsection

@section('styles')
  <link rel="stylesheet" href="{{ URL::to('css/form.css') }}">
@endsection
@section('content')
 @include('includes.info-box')
 <div align="right">
   <a href="{{ route('laravelqueue') }}" class="btn">Laravel Queue</a>
 </span>
 {!! Form::open(['route' => 'contact.send', 'id' => 'contact-form']) !!}
    <div class="input-group">
     {!! Form::label('name', 'Your name') !!}
     {!! Form::text('name', Request::old('name'), ['id' => 'name']) !!}
   </div>
   <div class="input-group">
     {!! Form::label('name', 'Your email') !!}
     {!! Form::text('email', Request::old('email'), ['id' => 'email']) !!}
   </div>
   <div class="input-group">
     {!! Form::label('name', 'Your subject') !!}
     {!! Form::text('subject', Request::old('subject'), ['id' => 'subject']) !!}
   </div>
    <div class="input-group">
     {!! Form::label('name', 'Your message') !!}
     {!! Form::textarea('message', Request::old('message'), ['id' => 'message', 'rows' => '10']) !!}
   </div>
   {!! Form::submit('Submit message', ['class' => 'btn']) !!}
{!! Form::close() !!}
@endsection 