<footer class="main-footer">
 <nav>
   <ul>
     <li><a href="{{ route('about')}}">About</a></li>
   </ul>
 </nav>
</footer>