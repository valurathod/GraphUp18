<header> 
 <nav class="main-nav">
   <ul>
     <li><a href="{{ route('blog.index') }}">Blog</a></li>
     <li><a href="{{ route('about') }}">About me</a></li>
     <li><a href="{{ route('contact') }}">Contact</a></li>
     <li><a href="{{ route('upload') }}">Upload</a></li>
   </ul>
 </nav>
</header>