<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="_token" content="{{ Session::token() }}">
    <title>Admin area</title>
    <link rel="stylesheet" href="{{ URL::to('css/admin.css')}}">
    @yield('styles')
  </head>
  <body>
  @include('includes.admin-header')
      @yield('content')
      <script type="text/stylesheet">
        var baseUrl = "{{ URL::to('/') }}";
      </script>
   @yield('scripts')
  </body>
</html>