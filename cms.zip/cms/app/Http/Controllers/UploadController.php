<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UploadController extends Controller
{
    public function uploadIndex()
    {
        return view('other.fileupload');
    }

    public function postUpload(Request $request)
    {
        $this->validate($request, [
            'fileupload' => 'required|mimes:jpeg,JPEG,JPG,png,jpg,gif,svg,pdf',
        ]);

        if ($request->hasFile('fileupload')) {
            $file = $request->file('fileupload');
            $imageName = time() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('images'), $imageName);
        }

        return back()
            ->with('success', 'You have successfully upload image.')
            ->with('fileupload', $imageName);
    }
}
