<?php
namespace App\Http\Controllers\api;

use App\Post;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
//use App\Http\Requests\ProjectVueValidation;

class ProjectsController extends Controller
{
     public function destroy($post_id)
    {
        echo 'success';
    }
}