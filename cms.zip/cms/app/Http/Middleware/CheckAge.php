<?php

namespace App\Http\Middleware;

use Closure;

class CheckAge
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($request->age > 120) {
            return redirect()->route('admin.blog.create_post')->with(['fail' => 'Age should be less than 120.']);
        }

        return $next($request);
    }
}
