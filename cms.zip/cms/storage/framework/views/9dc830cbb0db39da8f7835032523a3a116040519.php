<?php $__env->startSection('title'); ?>
  About me
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <h1>My name is ....</h1>
 <p>Apart from the well set-up beach, temple and the MTDC Resort, one can find various accommodation facilities here. Harihareshwar witnesses an annual celebration of the Kal Bhairav Jayanti Utsav, which is a famous festival, celebrated on the birth of the deity Kal Bhairav. This tradition was initiated by Mr Yashawant Balawant Nagle, who was the Sardar of Queen of Janjira administrating the Harihareshwar Village. He also funded the Temple Management by donating a significant chunk of his properties.
 </p>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>