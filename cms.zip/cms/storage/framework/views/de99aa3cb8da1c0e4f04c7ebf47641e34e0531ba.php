<?php $__env->startSection('title'); ?>
  Contact
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(URL::to('css/form.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <div align="right">
   <a href="<?php echo e(route('contact')); ?>" class="btn">Back</a>
 </span>
 <?php echo Form::open(['route' => 'contact.sendbyqueue', 'id' => 'contact-form']); ?>

    <div class="input-group">
     <?php echo Form::label('name', 'Your name'); ?>

     <?php echo Form::text('name', Request::old('name'), ['id' => 'name']); ?>

   </div>
   <div class="input-group">
     <?php echo Form::label('name', 'Your email'); ?>

     <?php echo Form::text('email', Request::old('email'), ['id' => 'email']); ?>

   </div>
   <div class="input-group">
     <?php echo Form::label('name', 'Your subject'); ?>

     <?php echo Form::text('subject', Request::old('subject'), ['id' => 'subject']); ?>

   </div>
    <div class="input-group">
     <?php echo Form::label('name', 'Your message'); ?>

     <?php echo Form::textarea('message', Request::old('message'), ['id' => 'message', 'rows' => '10']); ?>

   </div>
   <?php echo Form::submit('Submit message', ['class' => 'btn']); ?>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>