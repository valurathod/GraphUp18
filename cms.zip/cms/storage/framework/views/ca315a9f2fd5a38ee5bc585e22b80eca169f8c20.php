<h1>A new contact message was sent!</h1>
<h3>Information about your message</h3>
<p>Subject: <?php echo e($contact_message->subject); ?></p>
<p>Message: <?php echo e($contact_message->body); ?></p>