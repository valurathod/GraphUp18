<?php $__env->startSection('title'); ?>
  Contact
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(URL::to('css/form.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <?php echo $__env->make('includes.info-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php if($message = Session::get('success')): ?>
 <!--<img src="images/<?php echo e(Session::get('fileupload')); ?>" height="200" width="300">-->
 <a href="images/<?php echo e(Session::get('fileupload')); ?>" target="_blank"><?php echo e(Session::get('fileupload')); ?></a>
 <?php endif; ?>
 <?php echo Form::open(array('route' => 'upload.post','files'=>true, 'id' => 'contact-form')); ?>

    <div class="input-group">
     <?php echo Form::file('fileupload', array('id' => 'fileupload')); ?>

   </div>
   <?php echo Form::submit('Submit message', ['class' => 'btn']); ?>


 <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>