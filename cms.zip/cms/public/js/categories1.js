var tid = setInterval(function () {
    if (document.readyState !== "complete") {
        return;
    }
    clearInterval(tid);
}, 100);

$('.btn').click(function(event){
  event.preventDefault();
  var name = $('#name').val();
  if (name.length === 0) {
        alert("Please enter a valid Category name!");
        return;
    }
    
    var param = {'name': name, '_token': token};
   ajax('POST', "/admin/blog/category/create", param, newCategoryCreated, [name]);
});
function ajax(method, url, params, callback, callbackParams){
$.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
  $.ajax({
   url: baseUrl + url,
   data: {
       name : params['name'],
       _token : params['token']
   },
   error: function(error) {
      console.log(error);
   },
   dataType: 'json',
   success: function(data) {
       callback(callbackParams, true, data);
      //location.reload();
   },
   type: method
});
}

function newCategoryCreated(params, success, responseObj) {
    var name = params[0];
    location.reload();
}

// New edit implementation
var editSections = $('.edit');
for (i = 0; i < editSections.length; i++) {
    $(editSections[i].children[0].children[0].children[1].children[0]).on('click', startEdit);
    $(editSections[i].children[0].children[0].children[2].children[0]).on('click', startDelete);
}

function startEdit(event){
    event.preventDefault();
    event.target.innerHTML = 'Save';
    var li = $(event.target).parents().eq(1);
    var lis = $(event.target).parents().eq(4);
    $(li[0].children[0].children[0]).val($(lis[0].children[0].children[0]).html());
    $(li[0].children[0]).css('display', 'inline-block');
    setTimeout(function(){
        $(li[0].children[0].children[0]).css('maxWidth', '110px');
    });
    $(event.target).off('click', startEdit);
    $(event.target).on('click', saveEdit);
}

function saveEdit(event){
    event.preventDefault();
    var li = $(event.target).parents().eq(1);
    var lis = $(event.target).parents().eq(4);
    var categoryName = $(li[0].children[0].children[0]).val();
        var categoryId = $(lis[0].children[0]).data('id');
        if(categoryName.length === 0){
            alert('Please enter a valid category name.');
            return;
        }

    $.ajax({
            url: baseUrl + '/admin/blog/categories/update',
            data: {
                name:categoryName,
                category_id:categoryId,
                _token:token
            },
            error: function(error) {
                console.log(error);
            },
            dataType: 'json',
            success: function(data) {
                var newName = data['new_name'];
                $(lis).css('backgroundColor', '#afefac');
                setTimeout(function(){
                  $(lis).css('backgroundColor', 'white');
                }, 300);

                $(lis[0].children[0].children[0]).html(newName);
                event.target.innerHTML = 'Edit';
                $(li[0].children[0].children[0]).css('maxWidth', '0px');
                setTimeout(function(){
                   $(li[0].children[0]).css('display', 'none'); 
                }, 310);
            },
            type: 'POST'
        });    
        $(event.target).off('click', saveEdit);
        $(event.target).on('click', startEdit);
}

function startDelete(event) {
    // Open Modal here
    deleteCategory(event);

}

function deleteCategory(event){
    event.preventDefault();
    $(event.target).off('click', startDelete);
    var lis = $(event.target).parents().eq(4);
     var categoryId = $(lis[0].children[0]).data('id');
     console.log(categoryId);
      $.ajax({
            url: baseUrl + '/admin/blog/category/'+categoryId+'/delete',
            error: function(error) {
                console.log(error);
            },
            dataType: 'json',
            success: function(data) {
                $(lis).css('backgroundColor', '#ffc4be');
                setTimeout(function(){
                   $(lis).remove();
                   location.reload();
                }, 300);
            },
            type: 'DELETE'
        });    
}

