var addedCategoriesText;
var addedCategoriesIDs;

var tid = setInterval(function () {
    if (document.readyState !== "complete") {
        return;
    }
    clearInterval(tid);

    //var addCategoryBtn = document.getElementsByClassName('btn')[0];
    var addCategoryBtn = $('.btn').eq(0)[0];
    addedCategoriesIDs = $('#categories')[0];
    $(addCategoryBtn).on('click', addCategoryToPost);
    addedCategoriesText = $('.added-categories').eq(0)[0];
    
    for (i = 0; i < $(addedCategoriesText.children[0]).children().length; i++) {
//console.log($(addedCategoriesText.children[0].children[i]).first().children());
      //var cat = $(addedCategoriesText.children[0].children[i]).first().children();
      $($(addedCategoriesText.children[0].children[i]).first().children()).on('click', removeCategoryFromPost);
    }
   

}, 100);

function addCategoryToPost(event) {
    event.preventDefault();
    var select = $('#category_select');
    var selectedCategoryID = $("#category_select option:selected").val();
    var selectedCategoryName = $("#category_select option:selected").text();
    if (parseCategories().indexOf(selectedCategoryID) != -1) {
        return;
    }
    var data = $(addedCategoriesIDs).val();
    if (data.length > 0) {
        $(addedCategoriesIDs).val(data + "," + selectedCategoryID);
    } else {
        $(addedCategoriesIDs).val(selectedCategoryID);
    }
   
    var newCategoryLi = $("<li></li>");
    var newCategoryLink = $("<a></a>");
    $(newCategoryLink).attr('href','#');
    $(newCategoryLink).text(selectedCategoryName);
    $(newCategoryLink).attr('data-id',selectedCategoryID);
    //$(newCategoryLink).data('category_id', selectedCategoryID);
    $(newCategoryLink).on('click', removeCategoryFromPost);
    $(newCategoryLi).append(newCategoryLink);
    $(addedCategoriesText.children[0]).append(newCategoryLi);
    
}

function removeCategoryFromPost(event){
    event.preventDefault();
    $(event.target).off('click', removeCategoryFromPost);
    var categoryId = $(event.target).attr('data-id');
    var categoryIDArray = parseCategories();
    var index = categoryIDArray.indexOf(categoryId);
    categoryIDArray.splice(index, 1);
    var newCategoriesIDs = categoryIDArray.join(',');
    $(addedCategoriesIDs).val(newCategoriesIDs);
    $(event.target).parent().remove();

}
function parseCategories() {
    var data = $(addedCategoriesIDs).val();
    return data.split(",");
}
