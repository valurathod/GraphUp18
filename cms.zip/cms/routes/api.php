<?php

use Illuminate\Http\Request;
use app\Post;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
*/

Route::get('/posts',[
    'uses' => 'PostController@getPost',
    'as' => 'blog.index'
]);

Route::get('/categories',[
    'uses' => 'CategoryController@getCategories',
    'as' => 'admin.blog.categories'
]);

Route::get('/dashboard',[
    'uses' => 'AdminController@getData',
    'as' => 'admin.blog.dashboard'
]);

Route::post('/add_categories',[
    'uses' => 'CategoryController@postCategory',
    'as' => 'admin.blog.category'
]);

Route::delete('/delete_category/{id}',[
    'uses' => 'CategoryController@deleteCategory',
    'as' => 'admin.blog.category'
]);

Route::get('/contact-messages',[
    'uses' => 'ContactMessageController@getMessages',
    'as' => 'admin.blog.contact_messages'
]);

Route::delete('/deleteMessage/{message_id}',[
    'uses' => 'ContactMessageController@deleteMessage',
    'as' => 'admin.blog.contact_messages'
]);

/*Route::get('/deletepost/{post_id}', [
           'uses' => 'api\ProjectsController@destroy',
           'as' => 'admin.blog.post.delete'
       ]);*/

/*Route::delete('/user/{post_id}', [
    'uses' => 'UserController@user',
    'as' => 'admin.blog.post.delete'
]);    */   